<?php

if (isset($_POST['action']) && $_POST['action'] == 'waitlist') {
    # code...
    var_dump($_POST);
}